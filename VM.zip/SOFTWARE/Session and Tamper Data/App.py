# App.py file

from flask import Flask, request, session, redirect, url_for

app = Flask(__name__)
app.secret_key = "weakkey"

users = {
    "admin": "admin123",
    "guest": "guest123"
}

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        if username in users and users[username] == password:
            session["user"] = username
            return redirect("/welcome")

        return "<h3>Invalid Login</h3><a href='/'>Try Again</a>"

    return '''
    <h2>Login</h2>
    <form method="POST">
        Username: <input type="text" name="username"><br><br>
        Password: <input type="password" name="password"><br><br>
        <button type="submit">Login</button>
    </form>
    '''


@app.route("/welcome")
def welcome():
    if "user" in session:
        return f"<h2>Welcome {session['user']}</h2><br><a href='/logout'>Logout</a>"
    return redirect("/")


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)
